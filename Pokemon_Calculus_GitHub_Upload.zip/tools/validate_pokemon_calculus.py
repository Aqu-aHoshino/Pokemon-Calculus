#!/usr/bin/env python3
"""Static validation for Pokémon Calculus' Essentials PBS additions."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
pbs = ROOT / 'PBS'
species_text = (pbs/'pokemon.txt').read_text(encoding='utf-8-sig')
species = set(re.findall(r'^\[([^\]]+)\]', species_text, re.M))
trainer_types_text = (pbs/'trainer_types.txt').read_text(encoding='utf-8-sig')
trainer_types = set(re.findall(r'^\[([^\]]+)\]', trainer_types_text, re.M))
roster_file = ROOT/'Pokemon Calculus Project'/'REGIONAL_ROSTER.txt'
roster = [x.strip() for x in roster_file.read_text(encoding='utf-8-sig').splitlines() if x.strip() and not x.startswith('#')]
assert len(roster) == 50, f'Expected 50 roster species, got {len(roster)}'
assert len(set(roster)) == 50, 'Duplicate species in regional roster'
assert all(s in species for s in roster), 'Unknown species in regional roster'
trainers = (pbs/'trainers.txt').read_text(encoding='utf-8-sig')
expected = ['[RIVAL1,Mira]','[BUGCATCHER,Noel]','[YOUNGSTER,Paolo]','[CAMPER,Bea]','[HIKER,Ren]','[POKEMONTRAINER_May,Director Vale]']
for key in expected:
    assert key in trainers, f'Missing trainer record: {key}'
# Validate custom trainer classes against stock trainer type definitions.
for key in expected:
    trainer_type = key[1:].split(',')[0]
    assert trainer_type in trainer_types, f'Unknown trainer type: {trainer_type}'
# Validate all Pokémon named in the added trainer block.
custom = trainers[trainers.find(expected[0]):]
for name in re.findall(r'^Pokemon\s*=\s*([A-Z0-9]+)', custom, re.M):
    assert name in species, f'Unknown trainer Pokémon: {name}'
assert (ROOT/'Graphics'/'Characters'/'sir_aquino.png').is_file()
assert (ROOT/'Graphics'/'Titles'/'player_icon.png').is_file()
assert 'Title=Pokemon Calculus' in (ROOT/'Game.ini').read_text(encoding='utf-8-sig')
assert '[1] # Aster Regional Dex' in (pbs/'regional_dexes.txt').read_text(encoding='utf-8-sig')
print('PASS: 50 valid regional species')
print('PASS: 6 trainer parties and trainer classes')
print('PASS: Sir Aquino character sheet and player icon installed')
print('PASS: game title and Aster Regional Dex entry')
print('NOTE: map/event playability and PBS compilation require RPG Maker XP / Essentials runtime.')

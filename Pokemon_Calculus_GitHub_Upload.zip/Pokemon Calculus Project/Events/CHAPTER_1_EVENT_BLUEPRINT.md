# Chapter 1 event blueprint — Aster Region

This is the event-authoring blueprint for RPG Maker XP. It is intentionally explicit about the event pages, switches and commands needed; it is not a compiled `.rxdata` map.

## Switch contract
- `0001 PC_AQUINO_INTRO` — Sir Aquino introduction completed.
- `0002 PC_STARTER_CHOSEN` — starter handed over.
- `0003 PC_TRAIL_CLEARED` — Derivative Trail objective completed.
- `0004 PC_LENS_RECEIVED` — calibration lens received.
- `0005 PC_MIRA_DEFEATED` — Mira battle won.
- `0006 PC_CH1_COMPLETE` — chapter finale completed.

## Starter handoff event (Research Annex)
Create an Action Button event with Sir Aquino's graphic `sir_aquino`. Page 1 condition: switch 0001 OFF. Show the four intro lines from `SIR_AQUINO_EVENT.txt`; show the starter selection prompt; use three Show Choices: Bulbasaur / Charmander / Squirtle. In each branch use the Essentials Pokémon-giving command (`pbAddPokemon(:BULBASAUR,5)` or the matching species) and set switch 0002 ON. Add a conditional branch to avoid giving a second starter. Page 2 condition: switch 0002 ON; show the repeat greeting.

## Mira rival event (Old Survey Station)
Action Button or Player Touch event. Page 1 condition: switch 0003 ON and 0005 OFF. Show Mira's challenge line, start trainer battle using trainer type `RIVAL1`, trainer name `Mira`, and the team record in `PBS/trainers.txt`. On victory set switch 0005 ON. On loss, allow retry without setting the switch. Page 2 condition: switch 0005 ON; show the post-battle conversation.

## Sir Aquino chapter-end event
Page condition: switch 0005 ON. Show the Chapter End dialogue in `SIR_AQUINO_EVENT.txt`, set switch 0006 ON, and transfer/unlock the next destination.

## Trainer roster
Six trainer parties have been added to `PBS/trainers.txt`: Mira, Noel, Paolo, Bea, Ren and Director Vale. Their species and levels are deliberately early-game scaled.

## Map and encounter limitation
The current source archive has the original Essentials sample maps, not Aster Region map geometry. New Aster Town, Derivative Trail, Old Survey Station, Limit Cavern and Meridian City maps must still be created in RPG Maker XP and linked with transfers. Do not assign the new encounter table to unrelated sample maps.

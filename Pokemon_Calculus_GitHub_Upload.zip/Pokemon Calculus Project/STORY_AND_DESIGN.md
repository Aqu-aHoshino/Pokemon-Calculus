# Pokémon Calculus — story and gameplay plan

## Core premise
The Aster Region studies Pokémon movement, growth and battle strategy through observation. The player arrives in Aster Town during preparations for the annual Meridian Research Exhibition. Strange energy readings along the region's old observatories are disrupting Pokémon habitats. The mystery is investigated through exploration and battles—not classroom worksheets.

## Main cast
- **Sir Aquino** — a black-haired, glasses-wearing researcher and field mentor. Calm, observant and lightly humorous. He asks the player to notice patterns in Pokémon movement and the environment. He is never titled “Professor”.
- **Mira** — an energetic local trainer and friendly rival who values instinct over planning.
- **Tomas** — a quiet mechanic who maintains the region's old measurement stations.
- **Director Vale** — the exhibition organizer whose experiments have unintentionally destabilized the observatory network.

## One-hour first chapter (target pacing)
1. **Aster Town arrival (8 min):** player customization/name, meet Mira, visit the research annex, meet Sir Aquino and receive a starter Pokémon.
2. **Derivative Trail (12 min):** short route with three trainers, first wild encounters, a blocked footbridge and a movement-observation side path.
3. **Old Survey Station (12 min):** puzzle using switches and moving platforms; collect a calibration lens; first evidence of the strange readings.
4. **Mira's challenge (8 min):** rival battle near the station; post-battle dialogue introduces the next destination.
5. **Limit Cavern (12 min):** cave exploration, two optional item branches, a stronger wild encounter and a mini-boss trainer.
6. **Meridian City return (8 min):** report to Sir Aquino, reveal Director Vale's involvement, unlock the next route and close the chapter.

## Gameplay identity
- Standard Pokémon Essentials turn-based battles, status, items, party management and capture.
- Route exploration, optional paths, hidden items, trainer rematches and a rival battle.
- “Calculus” is a theme: rates of change, curves, maxima/minima and limits appear as environmental puzzles and dialogue metaphors. The game does not require solving formal equations to progress.
- Target initial regional roster: 50 species, listed in `REGIONAL_ROSTER.txt`.

## Dialogue tone
Keep lines short enough for RPG Maker message boxes. Sir Aquino is thoughtful, precise and supportive; avoid calling him “Professor Sir”. His name is **Sir Aquino**.

# Pokémon Calculus — source project

This folder contains the first production pass for Pokémon Calculus, built on the supplied Pokémon Essentials v21.1 / RPG Maker XP source project.

## What is already included
- The complete supplied Essentials project (engine scripts, compiled data, PBS source, maps, audio and graphics).
- Game window title changed to **Pokémon Calculus**.
- Original project brief and a one-hour story plan in `STORY_AND_DESIGN.md`.
- A 50-species regional roster proposal in `REGIONAL_ROSTER.txt`.
- Sir Aquino NPC dialogue and event-command implementation notes in `Events/SIR_AQUINO_EVENT.txt`.
- A first-pass RPG Maker XP-compatible 4x4 character sheet for Sir Aquino in `Art/sir_aquino.png`.
- A 256px player-icon concept in `Art/player_icon.png`.

## Important build status
This is a **source-project foundation and first content pass**, not a finished one-hour playable release yet. The supplied archive is Pokémon Essentials v21.1 and contains the engine and sample project data; it does not contain a prebuilt Pokémon Calculus story. The new story and roster are design/content assets and still need to be placed into RPG Maker XP map events, trainers, encounters and compiled PBS data. No claim is made that a new APK is included: Essentials v21.1 targets RPG Maker XP/Windows, and Android packaging requires a separate compatible runtime/port.

## Open the project
1. Use RPG Maker XP with a compatible RGSS runtime.
2. Open `Game.rxproj` in the project root.
3. Keep the `Data`, `Graphics`, `Audio`, `PBS`, `Plugins`, and `Fonts` folders together.
4. The supplied `Game.exe` is the Windows game runtime, not an Android APK.

## Next implementation pass
Create the new region's maps (Aster Town, Derivative Trail, Limit Cavern, Tangent Coast and Meridian City), place the dialogue from `Events`, configure wild encounters from `REGIONAL_ROSTER.txt`, add trainer teams, then compile the PBS data using the Essentials compiler.

## Asset notes
The player icon is a simple original pixel-art placeholder. Sir Aquino's sprite is a first-pass original placeholder; refine its palette/animation to match the existing Essentials character art before release.

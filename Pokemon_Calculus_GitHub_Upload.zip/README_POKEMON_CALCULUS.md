# Pokémon Calculus — reduced GitHub source upload

This is a size-reduced source package based on Pokémon Essentials v21.1. It retains engine/data files, PBS source, maps, fonts, core graphics, and Pokémon graphics for the 50-species Aster regional roster.

## What was removed to fit GitHub's browser upload limit
- Windows runtime executables and bundled runtime DLLs (install/use the compatible RPG Maker XP + RGSS runtime separately).
- Historical Gen 5–8 and Shadow Pokémon PBS backup folders.
- Pokémon graphics for species outside the Aster 50-species regional roster.
- Optional sound effects, music cues, and most large OGG background tracks. A small set of core battle/title tracks remains.

This package is intended for source upload and development, not as a finished playable release. Missing optional audio and out-of-region Pokémon graphics may need to be restored if later content references them.

## Open and prepare
1. Use a compatible Windows installation of RPG Maker XP and the RGSS runtime expected by Essentials v21.1.
2. Open `Game.rxproj` from the project root.
3. Compile PBS data using the Essentials Debug menu.
4. Run the static check with `python tools/validate_pokemon_calculus.py`.

## Current development status
This remains a source foundation and first content pass. The Aster maps, story events, encounters, and full playtesting still need implementation. It is not an Android APK.
